/ Javascript Using React libraray of reacrt components/ 

const { useState } = React;

function Calculator() {
  const [display, setDisplay] = useState("");

  const handleNumber = (number) => {
    setDisplay(display + number);
  };

  const handleOperator = (operator) => {
    setDisplay(display + operator);
  };

  const clearDisplay = () => {
    setDisplay("");
  };

  const evaluate = () => {
    try {
      setDisplay(eval(display).toString());
    } catch (error) {
      setDisplay("Error");
    }
  };

  const handleClear = () => {
    clearDisplay();
  };

  const handleDecimal = () => {
    setDisplay(display + ".");
  };

  const handleBackspace = () => {
    setDisplay(display.slice(0, -1));
  };

  return (
    <div className="calculator">
      <h1>Simple Calculator</h1>
      <input type="text" value={display} placeholder="0" disabled />
      <div className="buttons">
        <button className="operator" onClick={handleClear}>C</button>
        <button className="operator" onClick={() => handleOperator("%")}>%</button>
        <button className="operator" onClick={handleBackspace}>&#x232B;</button> {/* Backspace button */}
        <button className="operator" onClick={() => handleOperator("/")}>÷</button>
        <button onClick={() => handleNumber(7)}>7</button>
        <button onClick={() => handleNumber(8)}>8</button>
        <button onClick={() => handleNumber(9)}>9</button>
        <button className="operator" onClick={() => handleOperator("-")}>-</button>
        <button onClick={() => handleNumber(4)}>4</button>
        <button onClick={() => handleNumber(5)}>5</button>
        <button onClick={() => handleNumber(6)}>6</button>
        <button className="operator" onClick={() => handleOperator("*")}>×</button>
        <button onClick={() => handleNumber(1)}>1</button>
        <button onClick={() => handleNumber(2)}>2</button>
        <button onClick={() => handleNumber(3)}>3</button>
        <button className="operator" onClick={() => handleOperator("+")}>+</button>
        <button onClick={() => handleNumber("00")}>00</button>
        <button onClick={() => handleNumber(0)}>0</button>
        <button onClick={handleDecimal}>.</button>
        <button className="equal" onClick={evaluate}>=</button>
      </div>
    </div>
  );
}

ReactDOM.render(<Calculator />, document.getElementById('root'));